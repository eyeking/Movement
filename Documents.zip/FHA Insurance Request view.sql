CREATE OR REPLACE FORCE VIEW VW_FHA_B2G_INSURANCE_LOAN_INFO
(
   LOAN_NUM,
   MTG_SK_SEQ,
   APPL_TAKEN_TYPE,
   QUALIFYING_RATE,
   MI_FINANCED_FLAG,
   CASH_MIP,
   SELLER_CLOSING_COST_PERCENT,
   BUYER_RESERVE_MTHS,
   APPR_LICENSE_TYPE,
   PI_AMT,
   PRIOR_FLAG,
   LOAN_AMT,
   LIABILITY_WITHOUT_MIP,
   PURPOSE_TYPE,
   YEAR_BUILT_DATE,
   PROG_ID,
   ESCROW_REPAIR_FLAG,
   ESCROW_REPAIR_AMT,
   ESCROW_REPAIR_DT,
   APPR_AMT,
   ADP_CODE,
   ENERGY_EFFICIENT_INDICATOR,
   MFG_HOUSING_FLAG,
   FIRST_PAYMENT_DATE,
   CLOSING_DATE,
   NOTE_MATURITY_DATE,
   NEXT_PYMT_DATE,
   LTV,
   GFT1_RELATIONSHIP,
   GFT1_DONOR_NAME,
   GIFT1_TAX_ID,
   GFT2_RELATIONSHIP,
   GFT2_DONOR_NAME,
   GIFT2_TAX_ID,
   INTEREST_RATE,
   LOAN_TERM,
   NUM_UNITS_FINANCED,
   PROPERTY_TYPE,
   ACTUAL_RETURN_DATE,
   TOTAL_ROOMS,
   NUM_BEDROOMS,
   NUM_BATHROOMS,
   APPR_STATUS,
   PURCHASE_PRICE_AMT,
   LIVING_AREA_SQ_FEET,
   PROP_LOCATION_TYPE,
   BUILDING_TYPE,
   PUD_INDICATOR,
   BUILDING_STATUS_TYPE,
   AGENCY_CASE_NUM,
   PROP_SK_SEQ,
   SALE_AGREEMENT_DATE,
   OWNED_PERCENT,
   NBRHOOD_PRICE,
   SINGLE_FAM_PCT,
   TWO_FOUR_FAM_PCT,
   MULTI_FAM_PCT,
   COMMERCL_PCT,
   LVG_SQFT,
   LOT_ACRES,
   FOUNDATION_TYPE,
   AIR_COND_FLAG,
   PARKING_TYPE,
   SITE_VALUE,
   SALE_LAST_3YR_FLAG,
   PRIOR_SALE_DATE,
   PRIOR_SALE_AMT,
   CREATE_USER,
   ESCROW_REP_COMPL_DATE,
   BORR_CLOSING_COST,
   SELLER_CLOSING_COST,
   BORR_FUND_TO_CLOSE_REQUIRED,
   GFT_AMOUNT,
   LINE_12J,
   LINE_13F,
   LINE_15H,
   APPR_DATE,
   CHUMS_ID,
   SOLAR_HEATING_PRESENT,
   MATURITY_DATE,
   SELF_EMP_FLAG,
   YEARS_EMPLOYED,
   CUR_HOUS_EXP,
   APRSL_UWRTR,
   APPR_LIC,
   ORIG_ID,
   ADJ_TYPE,
   FHA_CONSULT_ID,
   USE_SPONSOR_NAME,
   MAIL_TO_SPONSOR,
   FIRST_TIME_BUYER_FLAG,
   COUNSELING_CONFIRMATION,
   CRFI_FLAG,
   BUILD_ON_OWN_LAND,
   MP_TYPE_DESC,
   BUYDOWN_FLAG,
   HOUSING_PROGRAM,
   SPECIAL_PROGRAM,
   PRIOR_FINANCE,
   SEC_FINANCING_SOURCE_IDTIN,
   SEC_FINANCING_SOURCE_EIN,
   SEC_FINANCING_SOURCE,
   SEC_FINANCING_SOURCE_TYPE,
   SEC_FINANCING_AMOUNT,
   CLTV,
   ARM_INDEX_TYPE,
   FHA_CONSTR_TO_PERM,
   MARGIN_RATE,
   CREDIT_SCORE_DECISION,
   CREDIT_SCORE_DECISION_DT,
   TOTAL_FIXED_PAYMENT_AMT,
   TOTAL_MORTGAGE_PAYMENT,
   UNPAID_PRINCIPAL_BALANCE,
   GIFT2_AMT,
   REQ_INVST,
   MI_WARRANTY_ENROLLED_NUM,
   FHAVA_CURRENT_PAYMENT,
   FHAVA_PRINCIPAL_REDUCTION,
   FHAVA_PRINCIPAL_REDUCT_AMT,
   COUNSELING_AGENCY_ID
)
AS
   SELECT   DISTINCT
            m.loan_num,
            m.mtg_sk_seq,
            DECODE (m.appl_taken_type,
                    'FACE', 'FaceToFaceInterview',
                    'MAIL', 'Mail',
                    'PHN', 'Telephone',
                    'WEB', 'Internet',
                    'FaceToFaceInterview')
               appl_taken_type,
            mp.qualifying_rate,
            los.SF_GET_FHA_MI_FINANCED_FLAG (m.mtg_sk_seq) mi_financed_flag,
            BRAVURA.sf_get_fee_gross_amt (m.mtg_sk_seq, 906) cash_mip,
            (vw45L.seller_contribution * 100) seller_closing_cost_percent,
            vw45L.NUM_MTHS_IN_RESERVE buyer_reserve_mths,
            CASE
               WHEN (appr_lt.license_type = 'CERT')
               THEN
                  'CertifiedGeneral'
               WHEN (appr_lt.license_type = 'GEN')
               THEN
                  'CertifiedResidential'
               WHEN (appr_lt.license_type = 'LIC')
               THEN
                  'Licensed'
               ELSE
                  ''
            END
               appr_license_type,
            TO_CHAR (mp.pi_amt) pi_amt,
            CASE
               WHEN (mp.purpose_type = 'STRA' OR mp.purpose_type = 'STRN')
               THEN
                  (DECODE (mgov.closed_before_07191_flag, 'Y', 'Yes', 'No'))
            END
               prior_flag,
            bravura.sf_calc_govt_gross_loan_amt2 (mp.mtg_sk_seq,
                                                  mp.guarantor_type,
                                                  mp.loan_amt,
                                                  mp.mp_sk_seq,
                                                  mp.loan_term,
                                                  mp.purpose_type)
               loan_amt,
            mp.loan_amt liability_without_mip,
            los.sf_get_fha_loan_purpose (purpose_type,
                                         pr.property_type,
                                         pr.building_status_type,
                                         mgov.finance_repairs_flag)
               purpose_type,
            pr.year_built_date,
            CASE
               WHEN (m.hud_sect_of_act_type = '203H') THEN '02'
               WHEN (mp.buydown_rule_sk_seq IS NOT NULL) THEN '52'
               ELSE ''
            END
               prog_id,
            DECODE (
               bravura.sf_get_mtg_est_summary_amt (m.mtg_sk_seq,
                                                   'SUMSEC7TYP',
                                                   'LINB'),
               0,
               'No',
               'Yes'
            )
               escrow_repair_flag,
            ROUND(bravura.sf_get_mtg_est_summary_amt (m.mtg_sk_seq,
                                                      'SUMSEC7TYP',
                                                      'LINB'))
               escrow_repair_amt,
            TO_CHAR (escrow_rep_compl_date, 'YYYYMMDD') escrow_repair_dt,
            DECODE (mp.purpose_type, 'STRN', '', TO_CHAR (appr_amt)) appr_amt,
            mi.adp_code,
            DECODE (vw45L.energy_efficient_mtg, 'X', 'Yes', '')
               energy_efficient_indicator,
            --Added DECODE to MFG_HOUSING_FLAG ISPT 9876 JPP
            DECODE (pr.property_type, 'MFTR', 'Yes', 'DBLW', 'Yes', 'No')
               mfg_housing_flag,
            TO_CHAR (first_pymt_date, 'YYYYMMDD') first_payment_date,
            --ISPT 8758 Changes per Mortgagee Letter 2005-28 JPP
            TO_CHAR (mc.disbursement_date, 'YYYYMMDD') closing_date,
            TO_CHAR (ADD_MONTHS (first_pymt_date, mp.loan_term - 1),
                     'YYYYMMDD')
               note_maturity_date,
            next_pymt_date,
            ROUND (mp.ltv, 2) ltv,
            DECODE (
               gift_funds1.gft_relationship,
               'MOTH',
               'Relative',
               'BROT',
               'Relative',
               'SIST',
               'Relative',
               'FATH',
               'Relative',
               'OREL',
               'Relative',
               'GOVT',
               'GovernmentAssistance',
               'EMPL',
               'Employer',
               'NPRC',
               DECODE (gift_funds1.SELLER_FD_DPA,
                       'Y', 'SellerFundedNonProfitReligiousCommunity',
                       'NonSellerFundedNonProfitReligiousCommunity'),
               'OTHR',
               'Relative',
               'N/A'
            )
               gft1_relationship,
            gift_funds1.gft_donor_name gft1_donor_name,
            CASE
               WHEN gift_funds1.gft_relationship IN ('GOVT', 'NPRC', 'EMPL')
               THEN
                  gift_funds1.gift_tax_id
            END
               gift1_tax_id,
            DECODE (
               gift_funds2.gft_relationship,
               'MOTH',
               'Relative',
               'BROT',
               'Relative',
               'SIST',
               'Relative',
               'FATH',
               'Relative',
               'OREL',
               'Relative',
               'GOVT',
               'GovernmentAssistance',
               'EMPL',
               'Employer',
               'NPRC',
               DECODE (gift_funds2.SELLER_FD_DPA,
                       'Y', 'SellerFundedNonProfitReligiousCommunity',
                       'NonSellerFundedNonProfitReligiousCommunity'),
               'OTHR',
               'Relative',
               'N/A'
            )
               gft2_relationship,
            gift_funds2.gft_donor_name gft2_donor_name,
            CASE
               WHEN gift_funds2.gft_relationship IN ('GOVT', 'NPRC', 'EMPL')
               THEN
                  gift_funds2.gift_tax_id
            END
               gift2_tax_id,
            mp.interest_rate,
            mp.loan_term,
            pr.num_units_financed,
            pr.property_type,
            TO_CHAR (pa2.actual_return_date, 'MMDDYY') actual_return_date,
            total_rooms,
            pa3.num_bedrooms,
            pa3.num_bathrooms,
            pa2.appr_status,
            ROUND (DECODE (mp.purpose_type, 'PUR', purchase_price_amt, ''))
               purchase_price_amt,
            pr.living_area_sq_feet,
            pr.prop_location_type,
            pr.building_type,
            CASE
               WHEN (pr.property_type = 'PUD' OR pr.pud_flag = 'Y')
               THEN
                  'Yes'
               ELSE
                  'No'
            END
               pud_indicator,
            DECODE (TRIM (pr.building_status_type),
                    'ENPO', 'Existing',
                    'EXS', 'Existing',
                    'ARLE', 'Existing',
                    'PRP', 'Proposed',
                    'SLRE', 'SubstantiallyRehabilitated',
                    'UCS', 'UnderConstruction',
                    '')
               building_status_type,
            -- Use two functions to remove all but the digits 0-9 from the case number.
            SUBSTR (
               TRANSLATE (
                  m.agency_case_num,
                  los.sf_fha_case_safe_chars || los.sf_fha_case_exclude_chars,
                  los.sf_fha_case_safe_chars
               ),
               1,
               10
            )
               agency_case_num,
            pa.prop_sk_seq,
            TO_CHAR (sale_agreement_date, 'MMDDYY') sale_agreement_date,
            pa.owned_percent,
            pa.nbrhood_price,
            pa.single_fam_pct,
            pa.two_four_fam_pct,
            pa.multi_fam_pct,
            pa.commercl_pct,
            pa.lvg_sqft,
            pa.lot_acres,
            pa.foundation_type,
            pa.air_cond_flag,
            pa.parking_type,
            pa.site_value,
            pa.sale_last_3yr_flag,
            TO_CHAR (pa.prior_sale_date, 'YYYYMMDD') prior_sale_date,
            pa.prior_sale_amt,
            pa.create_user,
            TO_CHAR (pa.escrow_rep_compl_date, 'YYYYMMDD')
               escrow_rep_compl_date,
            TRUNC (mgov.borr_paid_clos_costs_amt, 0) borr_closing_cost,
            TRUNC (mgov.seller_paid_clos_costs_amt) seller_closing_cost,
            TRUNC (vw45L.required, 0) borr_fund_to_close_required,
            ROUND (vw45L.gift1_amt) gft_amount,
            vw45L.verified_assets line_12j,
            TRUNC (vw45L.total_income_total, 0) line_13f,
            TRUNC (vw45L.total_mtg_payment, 0) line_15h,
            TO_CHAR (vw45L.esign_date, 'YYYYMMDD') appr_date,
            --ISPT 8759 Added Risk Class of ApproveIneligible 6-29-2005 JPP
            --Updated case statement to account for Streamline Refi's ISPT 9876 JPP
            mgov.CHUMS_NUM chums_id,
            DECODE (mgov.solar_energy_system_amt, NULL, 'No', 0, 'No', 'Yes')
               solar_heating_present,
            TO_CHAR (ADD_MONTHS (next_pymt_date, mp.loan_term), 'YYYYMMDD')
               maturity_date,
            CASE
               WHEN (be.self_employed_flag = 'Y'
                     AND be.percent_bus_owned > 25)
               THEN
                  'Yes'
               ELSE
                  'No'
            END
               self_emp_flag,
            ROUND ( (SYSDATE - be.start_date) / 365) years_employed,
            ROUND (sf_calc_total_mtg_expense (m.mtg_sk_seq)) cur_hous_exp,
            DECODE (mp.purpose_type, 'STRN', '', pa2.cond_commit_chums_id)
               aprsl_uwrtr,
            --ISPT 9876 only send APPR info when not streamline w/o appr JPP
            DECODE (mp.purpose_type,
                    'STRN', '',
                    (appr_l.state_code || appr_l.fha_num))
               appr_lic,
            l.fha_num orig_id,
            TRIM(TO_CHAR (BRAVURA.sf_get_adj_amt (m.mtg_sk_seq, 'PAD1') / 12,
                          '00'))
               adj_type,
            -- ISPT 9438
            mi.fha_consult_id fha_consult_id,
            'No' use_sponsor_name,
            CASE
               WHEN m.RETAIL_WHLSALE_TYPE IN ('W', 'C')
                    AND (SF_CHECK_LENDER_OPTION (m.LENDER_SK_SEQ, 'FHSE') !=
                            1)
               THEN
                  'Yes'
               ELSE
                  'No'
            END
               mail_to_sponsor,
            DECODE (los.sf_calc_first_time_buyer (m.mtg_sk_seq),
                    0, 'No',
                    'Yes')
               first_time_buyer_flag,
            BRAVURA.sf_get_code_description (mgov.COUNSELING_CONFIRM_TYPE,
                                             'COUCNF')
               counseling_confirmation,
            DECODE (mp.purpose_type, 'CRFI', 'Y', 'N') crfi_flag,
            DECODE (mgov.fha_owned_land_flag, 'Y', 'Yes', 'No')
               build_on_own_land,
            DECODE (mp.mp_type,
                    'FIX', 'Fixed',
                    'ARM', 'AdjustableRateMortgage',
                    NULL)
               mp_type_desc,
            DECODE (mp.buydown_rule_sk_seq, NULL, 'No', 'Yes') buydown_flag,
            los.sf_get_fha_housing_program (m.hud_sect_of_act_type,
                                            pr.property_type)
               housing_program,
            DECODE (
               INSTR (
                  bravura.sf_get_system_preference (
                     'FHA_MILITARY_IMPACT_COUNTIES',
                     pr.state_code
                  ),
                  pr.county
               ),
               0,
               'NoSpecialProgram',
               NULL,
               'NoSpecialProgram',
               'MilitaryImpactArea'
            )
               special_program,
            los.sf_get_fha_prior_finance_flag (mp.mp_sk_seq, mp.purpose_type)
               prior_finance,
            CASE
               WHEN mgov.sec_financing_source_type != 'OTH'
                    AND mgov.SEC_FINANCING_SOURCE_EIN IS NOT NULL
               THEN
                  'TIN'
               ELSE
                  ''
            END
               sec_financing_source_idtin,
            TRIM (mgov.sec_financing_source_ein),
            mgov.sec_financing_source,
            DECODE (mgov.sec_financing_source_type,
                    'FMLY', 'PrivateOrganizationsEligibleIndividuals',
                    'OTH', 'PrivateOrganizationsEligibleIndividuals',
                    'GOVT', 'GovernmentNonprofitInstrumentalityofGovernment',
                    'NP', 'NonProfitNotInstrumentalityofGovernment',
                    'LEND', 'Lender',
                    '')
               sec_financing_source_type,
            ROUND(bravura.sf_get_mtg_est_summary_amt (m.mtg_sk_seq,
                                                      'SUMSEC7TYP',
                                                      'LINJ'))
               sec_financing_amount,
            CASE
               WHEN (bravura.sf_get_mtg_est_summary_amt (m.mtg_sk_seq,
                                                         'SUMSEC7TYP',
                                                         'LINJ') > 0)
               THEN
                  TRIM (TO_CHAR (ROUND (mp.cltv, 2), '999.99'))
               ELSE
                  ''
            END
               cltv,
            DECODE (ai.arm_index_id,
                    '1 YR TREAS', 'CMT1YEAR',
                    '1Y_LIBOR', 'LIBOR1YEAR',
                    '')
               arm_index_type,
            DECODE (mp.purpose_type,
                    'CNPM', 'ConstructionToPermanent',
                    'Other')
               fha_constr_to_perm,
            bravura.sf_get_margin (m.mtg_sk_seq) margin_rate,
            los.sf_get_aus_scorecard_response (m.mtg_sk_seq)
               credit_score_decision,
            los.sf_get_aus_scorecard_date (m.mtg_sk_seq)
               credit_score_decision_dt,
            ROUND (vw45L.TOTAL_MTG_PAYMENT) total_fixed_payment_amt,
            ROUND (vw45L.tot_fixed_pmt_monthly) total_mortgage_payment,
            CASE
               WHEN mp.purpose_type IN ('STRA', 'STRN')
               THEN
                  ROUND (mgov.orig_unpaid_balance)
               ELSE
                  ROUND (pr.purchase_price_amt)
            END
               unpaid_principal_balance,
            ROUND (vw45L.gift2_amt),
            DECODE (
               mp.PURPOSE_TYPE,
               'PUR',
               CASE
                  WHEN mgov.assign_agency_case_num_date <
                          TO_DATE ('01/01/2009', 'MM/DD/YYYY')
                  THEN
                     ROUND (pr.purchase_price_amt * 0.03)
                  ELSE
                     ROUND (pr.purchase_price_amt * 0.035)
               END,
               NULL
            )
               req_invst,
            mgov.MI_WARRANTY_ENROLLED_NUM mi_warranty_enrolled_num,
            DECODE (mgov.FHAVA_CURRENT_PAYMENT, 'Y', 'Yes', 'No')
               fhava_current_payment,
            DECODE (mgov.FHAVA_PRINCIPAL_REDUCTION, 'Y', 'Yes', 'No')
               fhava_principal_reduction,
            ROUND (mgov.FHAVA_PRINCIPAL_REDUCT_AMT)
               fhava_principal_reduct_amt,
            mgov.COUNSELING_AGENCY_ID counseling_agency_id
     FROM   mortgage m,
            mtg_mp mp,
            mtg_closing mc,
            prop_addl_info pa,
            prop_appr pa2,
            borr_emp be,
            borr_mtg bm,
            borrower b,
            prop_appr_unit pa3,
            mtg_misc_info mi,
            (SELECT   *
               FROM   mtg_gift_funds mgf
              WHERE   gft_seq_num =
                         nshah_dev.sf_get_gift_fund_for_rownum (
                            MGF.MTG_SK_SEQ,
                            1
                         )) gift_funds1,
            (SELECT   *
               FROM   mtg_gift_funds mgf
              WHERE   gft_seq_num =
                         nshah_dev.sf_get_gift_fund_for_rownum (
                            MGF.MTG_SK_SEQ,
                            2
                         )) gift_funds2,
            property pr,
            vw_form_45l vw45L,
            mtg_govt mgov,
            contact_appr appr,
            contact_appr_license appr_l,
            contact_appr_license_type appr_lt,
            lender_license l,
            mortgage_product mpp,
            arm_index ai
    WHERE       m.mtg_sk_seq = mp.mtg_sk_seq
            AND m.mtg_sk_seq = mc.mtg_sk_seq
            AND m.mtg_sk_seq = mgov.mtg_sk_seq
            AND mp.mtg_sk_seq = mi.mtg_sk_seq(+)
            AND m.prop_sk_seq = pa.prop_sk_seq
            AND pa.prop_sk_seq = pa2.prop_sk_seq
            AND pr.prop_sk_seq = pa2.prop_sk_seq
            AND pa3.prop_sk_seq = pr.prop_sk_seq
            AND vw45L.mtg_sk_seq = m.mtg_sk_seq
            AND bm.mtg_sk_seq = m.mtg_sk_seq
            AND b.borr_sk_seq = bm.borr_sk_seq
            AND bm.borr_sk_seq = be.borr_sk_seq
            AND m.lender_sk_seq = l.lender_sk_seq
            AND mpp.mp_sk_seq = mp.mp_sk_seq
            AND mpp.arm_index_sk_seq = ai.arm_index_sk_seq(+)
            AND NVL (appr_l.state_code, l.state_code) = l.state_code
            AND appr.contact_sk_seq(+) = pa2.appraiser_sk_seq
            AND appr_l.contact_sk_seq(+) = appr.contact_sk_seq
            AND b.primary_borr_flag = 'Y'
            AND m.exp_date IS NULL
            AND mp.exp_date IS NULL
            AND pa2.exp_date IS NULL
            AND pa3.exp_date IS NULL
            AND pr.exp_date IS NULL
            AND mgov.exp_date IS NULL
            AND appr.exp_date IS NULL
            AND mc.exp_date IS NULL
            AND be.exp_date IS NULL
            AND bm.exp_date IS NULL
            AND b.exp_date IS NULL
            AND l.exp_date IS NULL
            AND mpp.exp_date IS NULL
            AND ai.exp_date IS NULL
            AND appr_lt.cal_sk_seq(+) = appr_l.cal_sk_seq
            AND pr.state_code = NVL (appr_l.state_code, pr.state_code)
            AND vw45L.user_skey = 1140
            AND m.mtg_sk_seq = gift_funds1.mtg_sk_seq(+)
            AND m.mtg_sk_seq = gift_funds2.mtg_sk_seq(+);

